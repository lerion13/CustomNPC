package net.minecraft.client.gui.inventory;

import net.minecraft.client.gui.inventory.GuiContainer;

public class NPCGuiContainerHelper {

   public static int getLeft(GuiContainer gui) {
      return gui.guiLeft;
   }

   public static int getTop(GuiContainer gui) {
      return gui.guiTop;
   }
}
