package noppes.npcs;

import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.gameevent.PlayerEvent.PlayerLoggedInEvent;
import cpw.mods.fml.common.gameevent.TickEvent.Phase;
import cpw.mods.fml.common.gameevent.TickEvent.WorldTickEvent;
import java.net.InetAddress;
import java.net.UnknownHostException;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.WorldServer;
import noppes.npcs.NPCSpawning;
import noppes.npcs.client.AnalyticsTracking;

public class ServerTickHandler {

   private String serverName = null;


   @SubscribeEvent
   public void onServerTick(WorldTickEvent event) {
      if(event.phase == Phase.START) {
         NPCSpawning.findChunksForSpawning((WorldServer)event.world);
      }

   }

   @SubscribeEvent
   public void playerLogin(PlayerLoggedInEvent event) {
      if(this.serverName == null) {
         String e = "local";
         MinecraftServer server = MinecraftServer.getServer();
         if(server.isDedicatedServer()) {
            try {
               e = InetAddress.getByName(server.func_71211_k()).getCanonicalHostName();
            } catch (UnknownHostException var5) {
               e = MinecraftServer.getServer().func_71211_k();
            }

            if(server.func_71234_u() != 25565) {
               e = e + ":" + server.func_71234_u();
            }
         }

         if(e == null || e.startsWith("192.168") || e.contains("127.0.0.1") || e.startsWith("localhost")) {
            e = "local";
         }

         this.serverName = e;
      }

      AnalyticsTracking.sendData(event.player, "join", this.serverName);
   }
}
