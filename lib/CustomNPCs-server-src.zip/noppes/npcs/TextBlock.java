package noppes.npcs;

import java.util.ArrayList;
import java.util.List;

public class TextBlock {

   public List lines = new ArrayList();


}
