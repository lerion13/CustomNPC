package noppes.npcs.constants;


public enum EnumQuestCompletion {

   Npc("Npc", 0),
   Instant("Instant", 1);
   // $FF: synthetic field
   private static final EnumQuestCompletion[] $VALUES = new EnumQuestCompletion[]{Npc, Instant};


   private EnumQuestCompletion(String var1, int var2) {}

}
