package noppes.npcs.constants;


public enum EnumAvailabilityFaction {

   Friendly("Friendly", 0),
   Neutral("Neutral", 1),
   Hostile("Hostile", 2);
   // $FF: synthetic field
   private static final EnumAvailabilityFaction[] $VALUES = new EnumAvailabilityFaction[]{Friendly, Neutral, Hostile};


   private EnumAvailabilityFaction(String var1, int var2) {}

}
