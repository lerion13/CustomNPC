package noppes.npcs.constants;


public enum EnumAvailabilityDialog {

   Always("Always", 0),
   After("After", 1),
   Before("Before", 2);
   // $FF: synthetic field
   private static final EnumAvailabilityDialog[] $VALUES = new EnumAvailabilityDialog[]{Always, After, Before};


   private EnumAvailabilityDialog(String var1, int var2) {}

}
