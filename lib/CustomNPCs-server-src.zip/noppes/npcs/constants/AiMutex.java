package noppes.npcs.constants;


public class AiMutex {

   public static byte PASSIVE = 1;
   public static byte LOOK = 2;
   public static byte PATHING = 4;


}
