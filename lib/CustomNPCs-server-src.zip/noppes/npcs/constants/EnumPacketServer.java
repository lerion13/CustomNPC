package noppes.npcs.constants;

import noppes.npcs.CustomNpcsPermissions;

public enum EnumPacketServer {

   Delete("Delete", 0, CustomNpcsPermissions.NPC_DELETE, true),
   RemoteMainMenu("RemoteMainMenu", 1, CustomNpcsPermissions.NPC_GUI),
   NpcMenuClose("NpcMenuClose", 2, CustomNpcsPermissions.NPC_GUI, true),
   RemoteDelete("RemoteDelete", 3, CustomNpcsPermissions.NPC_DELETE, true),
   RemoteFreeze("RemoteFreeze", 4, CustomNpcsPermissions.NPC_FREEZE),
   RemoteReset("RemoteReset", 5, CustomNpcsPermissions.NPC_RESET),
   SpawnMob("SpawnMob", 6, CustomNpcsPermissions.SPAWNER_MOB),
   MobSpawner("MobSpawner", 7, CustomNpcsPermissions.SPAWNER_CREATE),
   MainmenuAISave("MainmenuAISave", 8, CustomNpcsPermissions.NPC_AI, true),
   MainmenuAIGet("MainmenuAIGet", 9, true),
   MainmenuInvSave("MainmenuInvSave", 10, CustomNpcsPermissions.NPC_INVENTORY, true),
   MainmenuInvGet("MainmenuInvGet", 11, true),
   MainmenuStatsSave("MainmenuStatsSave", 12, CustomNpcsPermissions.NPC_STATS, true),
   MainmenuStatsGet("MainmenuStatsGet", 13, true),
   MainmenuDisplaySave("MainmenuDisplaySave", 14, CustomNpcsPermissions.NPC_DISPLAY, true),
   MainmenuDisplayGet("MainmenuDisplayGet", 15, true),
   ModelDataSave("ModelDataSave", 16, CustomNpcsPermissions.NPC_DISPLAY, true),
   MainmenuAdvancedSave("MainmenuAdvancedSave", 17, CustomNpcsPermissions.NPC_ADVANCED, true),
   MainmenuAdvancedGet("MainmenuAdvancedGet", 18, true),
   DialogNpcSet("DialogNpcSet", 19, CustomNpcsPermissions.NPC_ADVANCED),
   DialogNpcRemove("DialogNpcRemove", 20, CustomNpcsPermissions.NPC_ADVANCED, true),
   FactionSet("FactionSet", 21, CustomNpcsPermissions.NPC_ADVANCED, true),
   TransportSave("TransportSave", 22, CustomNpcsPermissions.NPC_ADVANCED, true),
   TransformSave("TransformSave", 23, CustomNpcsPermissions.NPC_ADVANCED, true),
   TransformGet("TransformGet", 24, true),
   TransformLoad("TransformLoad", 25, CustomNpcsPermissions.NPC_ADVANCED, true),
   TraderMarketSave("TraderMarketSave", 26, CustomNpcsPermissions.NPC_ADVANCED, true),
   JobSave("JobSave", 27, CustomNpcsPermissions.NPC_ADVANCED, true),
   JobGet("JobGet", 28, true),
   RoleSave("RoleSave", 29, CustomNpcsPermissions.NPC_ADVANCED, true),
   RoleGet("RoleGet", 30, true),
   JobSpawnerAdd("JobSpawnerAdd", 31, CustomNpcsPermissions.NPC_ADVANCED, true),
   JobSpawnerRemove("JobSpawnerRemove", 32, CustomNpcsPermissions.NPC_ADVANCED, true),
   RoleCompanionUpdate("RoleCompanionUpdate", 33, CustomNpcsPermissions.NPC_ADVANCED, true),
   LinkedSet("LinkedSet", 34, CustomNpcsPermissions.NPC_ADVANCED, true),
   ClonePreSave("ClonePreSave", 35, CustomNpcsPermissions.NPC_CLONE),
   CloneSave("CloneSave", 36, CustomNpcsPermissions.NPC_CLONE),
   CloneRemove("CloneRemove", 37, CustomNpcsPermissions.NPC_CLONE),
   CloneList("CloneList", 38),
   LinkedGetAll("LinkedGetAll", 39),
   LinkedRemove("LinkedRemove", 40, CustomNpcsPermissions.GLOBAL_LINKED),
   LinkedAdd("LinkedAdd", 41, CustomNpcsPermissions.GLOBAL_LINKED),
   ScriptDataSave("ScriptDataSave", 42, CustomNpcsPermissions.TOOL_SCRIPTER, true),
   ScriptDataGet("ScriptDataGet", 43, true),
   PlayerDataRemove("PlayerDataRemove", 44, CustomNpcsPermissions.GLOBAL_PLAYERDATA),
   BankSave("BankSave", 45, CustomNpcsPermissions.GLOBAL_BANK),
   BanksGet("BanksGet", 46),
   BankGet("BankGet", 47),
   BankRemove("BankRemove", 48, CustomNpcsPermissions.GLOBAL_BANK),
   DialogCategorySave("DialogCategorySave", 49, CustomNpcsPermissions.GLOBAL_DIALOG),
   DialogCategoriesGet("DialogCategoriesGet", 50),
   DialogsGetFromDialog("DialogsGetFromDialog", 51),
   DialogCategoryRemove("DialogCategoryRemove", 52, CustomNpcsPermissions.GLOBAL_DIALOG),
   DialogCategoryGet("DialogCategoryGet", 53),
   DialogSave("DialogSave", 54, CustomNpcsPermissions.GLOBAL_DIALOG),
   DialogsGet("DialogsGet", 55),
   DialogGet("DialogGet", 56),
   DialogRemove("DialogRemove", 57, CustomNpcsPermissions.GLOBAL_DIALOG),
   TransportCategoryRemove("TransportCategoryRemove", 58, CustomNpcsPermissions.GLOBAL_TRANSPORT),
   TransportGetLocation("TransportGetLocation", 59, true),
   TransportRemove("TransportRemove", 60, CustomNpcsPermissions.GLOBAL_TRANSPORT),
   TransportsGet("TransportsGet", 61),
   TransportCategorySave("TransportCategorySave", 62, CustomNpcsPermissions.GLOBAL_TRANSPORT),
   TransportCategoriesGet("TransportCategoriesGet", 63),
   FactionRemove("FactionRemove", 64, CustomNpcsPermissions.GLOBAL_FACTION),
   FactionSave("FactionSave", 65, CustomNpcsPermissions.GLOBAL_FACTION),
   FactionsGet("FactionsGet", 66),
   FactionGet("FactionGet", 67),
   QuestCategorySave("QuestCategorySave", 68, CustomNpcsPermissions.GLOBAL_QUEST),
   QuestCategoriesGet("QuestCategoriesGet", 69),
   QuestRemove("QuestRemove", 70, CustomNpcsPermissions.GLOBAL_QUEST),
   QuestCategoryRemove("QuestCategoryRemove", 71, CustomNpcsPermissions.GLOBAL_QUEST),
   QuestRewardSave("QuestRewardSave", 72, CustomNpcsPermissions.GLOBAL_QUEST),
   QuestSave("QuestSave", 73, CustomNpcsPermissions.GLOBAL_QUEST),
   QuestsGetFromQuest("QuestsGetFromQuest", 74),
   QuestsGet("QuestsGet", 75),
   QuestDialogGetTitle("QuestDialogGetTitle", 76, CustomNpcsPermissions.GLOBAL_QUEST),
   RecipeSave("RecipeSave", 77, CustomNpcsPermissions.GLOBAL_RECIPE),
   RecipeRemove("RecipeRemove", 78, CustomNpcsPermissions.GLOBAL_RECIPE),
   NaturalSpawnSave("NaturalSpawnSave", 79, CustomNpcsPermissions.GLOBAL_NATURALSPAWN),
   NaturalSpawnGet("NaturalSpawnGet", 80),
   NaturalSpawnRemove("NaturalSpawnRemove", 81, CustomNpcsPermissions.GLOBAL_NATURALSPAWN),
   MerchantUpdate("MerchantUpdate", 82, CustomNpcsPermissions.EDIT_VILLAGER),
   PlayerRider("PlayerRider", 83, CustomNpcsPermissions.TOOL_MOUNTER),
   SpawnRider("SpawnRider", 84, CustomNpcsPermissions.TOOL_MOUNTER),
   MovingPathSave("MovingPathSave", 85, CustomNpcsPermissions.TOOL_PATHER, true),
   MovingPathGet("MovingPathGet", 86, true),
   DialogNpcGet("DialogNpcGet", 87),
   RecipesGet("RecipesGet", 88),
   RecipeGet("RecipeGet", 89),
   QuestOpenGui("QuestOpenGui", 90),
   PlayerDataGet("PlayerDataGet", 91),
   RemoteNpcsGet("RemoteNpcsGet", 92, CustomNpcsPermissions.NPC_GUI),
   RemoteTpToNpc("RemoteTpToNpc", 93),
   QuestGet("QuestGet", 94),
   QuestCategoryGet("QuestCategoryGet", 95),
   SaveTileEntity("SaveTileEntity", 96),
   NaturalSpawnGetAll("NaturalSpawnGetAll", 97),
   MailOpenSetup("MailOpenSetup", 98),
   DimensionsGet("DimensionsGet", 99),
   DimensionTeleport("DimensionTeleport", 100),
   GetTileEntity("GetTileEntity", 101),
   Gui("Gui", 102);
   public CustomNpcsPermissions.Permission permission;
   public boolean needsNpc;
   // $FF: synthetic field
   private static final EnumPacketServer[] $VALUES = new EnumPacketServer[]{Delete, RemoteMainMenu, NpcMenuClose, RemoteDelete, RemoteFreeze, RemoteReset, SpawnMob, MobSpawner, MainmenuAISave, MainmenuAIGet, MainmenuInvSave, MainmenuInvGet, MainmenuStatsSave, MainmenuStatsGet, MainmenuDisplaySave, MainmenuDisplayGet, ModelDataSave, MainmenuAdvancedSave, MainmenuAdvancedGet, DialogNpcSet, DialogNpcRemove, FactionSet, TransportSave, TransformSave, TransformGet, TransformLoad, TraderMarketSave, JobSave, JobGet, RoleSave, RoleGet, JobSpawnerAdd, JobSpawnerRemove, RoleCompanionUpdate, LinkedSet, ClonePreSave, CloneSave, CloneRemove, CloneList, LinkedGetAll, LinkedRemove, LinkedAdd, ScriptDataSave, ScriptDataGet, PlayerDataRemove, BankSave, BanksGet, BankGet, BankRemove, DialogCategorySave, DialogCategoriesGet, DialogsGetFromDialog, DialogCategoryRemove, DialogCategoryGet, DialogSave, DialogsGet, DialogGet, DialogRemove, TransportCategoryRemove, TransportGetLocation, TransportRemove, TransportsGet, TransportCategorySave, TransportCategoriesGet, FactionRemove, FactionSave, FactionsGet, FactionGet, QuestCategorySave, QuestCategoriesGet, QuestRemove, QuestCategoryRemove, QuestRewardSave, QuestSave, QuestsGetFromQuest, QuestsGet, QuestDialogGetTitle, RecipeSave, RecipeRemove, NaturalSpawnSave, NaturalSpawnGet, NaturalSpawnRemove, MerchantUpdate, PlayerRider, SpawnRider, MovingPathSave, MovingPathGet, DialogNpcGet, RecipesGet, RecipeGet, QuestOpenGui, PlayerDataGet, RemoteNpcsGet, RemoteTpToNpc, QuestGet, QuestCategoryGet, SaveTileEntity, NaturalSpawnGetAll, MailOpenSetup, DimensionsGet, DimensionTeleport, GetTileEntity, Gui};


   private EnumPacketServer(String var1, int var2) {
      this.permission = null;
      this.needsNpc = false;
   }

   private EnumPacketServer(String var1, int var2, CustomNpcsPermissions.Permission permission, boolean npc) {
      this(var1, var2, permission);
   }

   private EnumPacketServer(String var1, int var2, boolean npc) {
      this.permission = null;
      this.needsNpc = false;
      this.needsNpc = npc;
   }

   private EnumPacketServer(String var1, int var2, CustomNpcsPermissions.Permission permission) {
      this.permission = null;
      this.needsNpc = false;
      this.permission = permission;
   }

   public boolean hasPermission() {
      return this.permission != null;
   }

}
