package noppes.npcs.constants;


public enum EnumAvailabilityFactionType {

   Always("Always", 0),
   Is("Is", 1),
   IsNot("IsNot", 2);
   // $FF: synthetic field
   private static final EnumAvailabilityFactionType[] $VALUES = new EnumAvailabilityFactionType[]{Always, Is, IsNot};


   private EnumAvailabilityFactionType(String var1, int var2) {}

}
