package noppes.npcs.constants;


public enum EnumDayTime {

   Always("Always", 0),
   Night("Night", 1),
   Day("Day", 2);
   // $FF: synthetic field
   private static final EnumDayTime[] $VALUES = new EnumDayTime[]{Always, Night, Day};


   private EnumDayTime(String var1, int var2) {}

}
