package noppes.npcs.client.gui.advanced;

import net.minecraft.client.gui.GuiButton;
import net.minecraft.nbt.NBTTagCompound;
import noppes.npcs.client.Client;
import noppes.npcs.client.NoppesUtil;
import noppes.npcs.client.gui.GuiNPCLinesEdit;
import noppes.npcs.client.gui.util.GuiNPCInterface2;
import noppes.npcs.client.gui.util.GuiNpcButton;
import noppes.npcs.client.gui.util.GuiNpcButtonYesNo;
import noppes.npcs.client.gui.util.GuiNpcLabel;
import noppes.npcs.constants.EnumPacketServer;
import noppes.npcs.entity.EntityNPCInterface;

public class GuiNPCLinesMenu extends GuiNPCInterface2 {

   public GuiNPCLinesMenu(EntityNPCInterface npc) {
      super(npc);
   }

   public void initGui() {
      super.initGui();
      this.addButton(new GuiNpcButton(0, super.guiLeft + 85, super.guiTop + 20, "World Lines"));
      this.addButton(new GuiNpcButton(1, super.guiLeft + 85, super.guiTop + 43, "Attack Lines"));
      this.addButton(new GuiNpcButton(2, super.guiLeft + 85, super.guiTop + 66, "Interact Lines"));
      this.addButton(new GuiNpcButton(5, super.guiLeft + 85, super.guiTop + 89, "Killed Lines"));
      this.addButton(new GuiNpcButton(6, super.guiLeft + 85, super.guiTop + 112, "Kill Lines"));
      this.addLabel(new GuiNpcLabel(16, "Random Lines", super.guiLeft + 85, super.guiTop + 157));
      this.addButton(new GuiNpcButtonYesNo(16, super.guiLeft + 175, super.guiTop + 152, !super.npc.advanced.orderedLines));
   }

   protected void actionPerformed(GuiButton guibutton) {
      int id = guibutton.id;
      if(id == 0) {
         NoppesUtil.openGUI(super.player, new GuiNPCLinesEdit(super.npc, super.npc.advanced.worldLines));
      }

      if(id == 1) {
         NoppesUtil.openGUI(super.player, new GuiNPCLinesEdit(super.npc, super.npc.advanced.attackLines));
      }

      if(id == 2) {
         NoppesUtil.openGUI(super.player, new GuiNPCLinesEdit(super.npc, super.npc.advanced.interactLines));
      }

      if(id == 5) {
         NoppesUtil.openGUI(super.player, new GuiNPCLinesEdit(super.npc, super.npc.advanced.killedLines));
      }

      if(id == 6) {
         NoppesUtil.openGUI(super.player, new GuiNPCLinesEdit(super.npc, super.npc.advanced.killLines));
      }

      if(id == 16) {
         super.npc.advanced.orderedLines = !((GuiNpcButtonYesNo)guibutton).getBoolean();
      }

   }

   public void save() {
      Client.sendData(EnumPacketServer.MainmenuAdvancedSave, new Object[]{super.npc.advanced.writeToNBT(new NBTTagCompound())});
   }
}
