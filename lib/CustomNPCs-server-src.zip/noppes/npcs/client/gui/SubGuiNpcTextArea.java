package noppes.npcs.client.gui;

import net.minecraft.client.gui.GuiButton;
import noppes.npcs.NoppesStringUtils;
import noppes.npcs.client.gui.util.GuiNpcButton;
import noppes.npcs.client.gui.util.GuiNpcTextArea;
import noppes.npcs.client.gui.util.SubGuiInterface;

public class SubGuiNpcTextArea extends SubGuiInterface {

   public String text;
   private GuiNpcTextArea textarea;


   public SubGuiNpcTextArea(String text) {
      this.text = text;
      this.setBackground("bgfilled.png");
      super.xSize = 256;
      super.ySize = 256;
      super.closeOnEsc = true;
   }

   public void initGui() {
      super.xSize = (int)((double)super.width * 0.88D);
      super.ySize = (int)((double)super.xSize * 0.56D);
      super.bgScale = (float)super.xSize / 440.0F;
      super.initGui();
      if(this.textarea != null) {
         this.text = this.textarea.getText();
      }

      int yoffset = (int)((double)super.ySize * 0.02D);
      this.addTextField(this.textarea = new GuiNpcTextArea(2, this, super.guiLeft + yoffset, super.guiTop + yoffset, super.xSize - 100 - yoffset * 2, super.ySize - yoffset * 2, this.text));
      super.buttonList.add(new GuiNpcButton(102, super.guiLeft + super.xSize - 90 - yoffset, super.guiTop + 20, 56, 20, "gui.clear"));
      super.buttonList.add(new GuiNpcButton(101, super.guiLeft + super.xSize - 90 - yoffset, super.guiTop + 43, 56, 20, "gui.paste"));
      super.buttonList.add(new GuiNpcButton(100, super.guiLeft + super.xSize - 90 - yoffset, super.guiTop + 66, 56, 20, "gui.copy"));
      super.buttonList.add(new GuiNpcButton(0, super.guiLeft + super.xSize - 90 - yoffset, super.guiTop + 160, 56, 20, "gui.close"));
      super.xSize = 420;
      super.ySize = 256;
   }

   public void close() {
      this.text = this.getTextField(2).getText();
      super.close();
   }

   public void buttonEvent(GuiButton guibutton) {
      int id = guibutton.id;
      if(id == 100) {
         NoppesStringUtils.setClipboardContents(this.getTextField(2).getText());
      }

      if(id == 101) {
         this.getTextField(2).setText(NoppesStringUtils.getClipboardContents());
      }

      if(id == 102) {
         this.getTextField(2).setText("");
      }

      if(id == 0) {
         this.close();
      }

   }
}
