package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.SubGuiInterface;

public interface ISubGuiListener {

   void subGuiClosed(SubGuiInterface var1);
}
