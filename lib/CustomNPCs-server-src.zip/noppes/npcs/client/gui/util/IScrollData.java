package noppes.npcs.client.gui.util;

import java.util.HashMap;
import java.util.Vector;

public interface IScrollData {

   void setData(Vector var1, HashMap var2);

   void setSelected(String var1);
}
