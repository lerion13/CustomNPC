package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.GuiCustomScroll;

public interface ICustomScrollListener {

   void customScrollClicked(int var1, int var2, int var3, GuiCustomScroll var4);
}
