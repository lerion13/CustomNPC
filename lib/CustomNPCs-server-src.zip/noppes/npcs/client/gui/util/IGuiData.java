package noppes.npcs.client.gui.util;

import net.minecraft.nbt.NBTTagCompound;

public interface IGuiData {

   void setGuiData(NBTTagCompound var1);
}
