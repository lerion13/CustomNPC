package noppes.npcs.client.gui.util;


public interface ITopButtonListener {

   void mouseClicked(int var1, int var2, int var3);
}
