package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.GuiNpcSlider;

public interface ISliderListener {

   void mouseDragged(GuiNpcSlider var1);

   void mousePressed(GuiNpcSlider var1);

   void mouseReleased(GuiNpcSlider var1);
}
