package noppes.npcs.client.gui.util;


public interface IJTextAreaListener {

   void saveText(String var1);
}
