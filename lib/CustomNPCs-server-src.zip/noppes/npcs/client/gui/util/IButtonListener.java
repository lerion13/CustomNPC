package noppes.npcs.client.gui.util;

import net.minecraft.client.gui.GuiButton;

public interface IButtonListener {

   void actionPerformed(GuiButton var1);
}
