package noppes.npcs.client.gui.util;


public interface GuiSelectionListener {

   void selected(int var1, String var2);
}
