package noppes.npcs.client.gui.util;

import noppes.npcs.client.gui.util.GuiNpcTextField;

public interface ITextfieldListener {

   void unFocused(GuiNpcTextField var1);
}
