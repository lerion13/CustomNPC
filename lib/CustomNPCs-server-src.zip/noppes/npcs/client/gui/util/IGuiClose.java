package noppes.npcs.client.gui.util;

import net.minecraft.nbt.NBTTagCompound;

public interface IGuiClose {

   void setClose(int var1, NBTTagCompound var2);
}
