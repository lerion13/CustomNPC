package noppes.npcs.client;


public class ClientEventHandler {

}
