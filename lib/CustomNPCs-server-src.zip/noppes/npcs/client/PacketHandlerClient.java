package noppes.npcs.client;

import cpw.mods.fml.common.ObfuscationReflectionHelper;
import cpw.mods.fml.common.eventhandler.SubscribeEvent;
import cpw.mods.fml.common.network.FMLNetworkEvent.ClientCustomPacketEvent;
import io.netty.buffer.ByteBuf;
import java.io.IOException;
import java.util.HashMap;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityClientPlayerMP;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.achievement.GuiAchievement;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.nbt.NBTTagList;
import net.minecraft.network.PacketBuffer;
import net.minecraft.util.ChatComponentTranslation;
import net.minecraft.util.StatCollector;
import net.minecraft.village.MerchantRecipeList;
import noppes.npcs.CustomNpcs;
import noppes.npcs.NoppesStringUtils;
import noppes.npcs.PacketHandlerServer;
import noppes.npcs.Server;
import noppes.npcs.ServerEventsHandler;
import noppes.npcs.client.ClientProxy;
import noppes.npcs.client.EntityUtil;
import noppes.npcs.client.NoppesUtil;
import noppes.npcs.client.QuestAchievement;
import noppes.npcs.client.RenderChatMessages;
import noppes.npcs.client.controllers.MusicController;
import noppes.npcs.client.gui.GuiNpcMobSpawnerAdd;
import noppes.npcs.client.gui.player.GuiBook;
import noppes.npcs.client.gui.util.GuiContainerNPCInterface;
import noppes.npcs.client.gui.util.GuiNPCInterface;
import noppes.npcs.client.gui.util.IGuiClose;
import noppes.npcs.client.gui.util.IGuiData;
import noppes.npcs.client.gui.util.IGuiError;
import noppes.npcs.client.gui.util.IScrollData;
import noppes.npcs.constants.EnumGuiType;
import noppes.npcs.constants.EnumPacketClient;
import noppes.npcs.controllers.RecipeCarpentry;
import noppes.npcs.controllers.RecipeController;
import noppes.npcs.entity.EntityDialogNpc;
import noppes.npcs.entity.EntityNPCInterface;

public class PacketHandlerClient extends PacketHandlerServer {

   @SubscribeEvent
   public void onPacketData(ClientCustomPacketEvent event) {
      EntityClientPlayerMP player = Minecraft.getMinecraft().thePlayer;
      ByteBuf buffer = event.packet.payload();

      try {
         this.client(buffer, player, EnumPacketClient.values()[buffer.readInt()]);
      } catch (IOException var5) {
         var5.printStackTrace();
      }

   }

   private void client(ByteBuf buffer, EntityPlayer player, EnumPacketClient type) throws IOException {
      Entity config;
      if(type == EnumPacketClient.CHATBUBBLE) {
         config = Minecraft.getMinecraft().theWorld.getEntityByID(buffer.readInt());
         if(config == null || !(config instanceof EntityNPCInterface)) {
            return;
         }

         EntityNPCInterface font = (EntityNPCInterface)config;
         if(font.messages == null) {
            font.messages = new RenderChatMessages();
         }

         String size = NoppesStringUtils.formatText(Server.readString(buffer), new Object[]{player, font});
         font.messages.addMessage(size, font);
         if(buffer.readBoolean()) {
            player.addChatMessage(new ChatComponentTranslation(font.getCommandSenderName() + ": " + size, new Object[0]));
         }
      } else {
         String var7;
         String var8;
         if(type == EnumPacketClient.CHAT) {
            for(var7 = ""; (var8 = Server.readString(buffer)) != null && !var8.isEmpty(); var7 = var7 + StatCollector.translateToLocal(var8)) {
               ;
            }

            player.addChatMessage(new ChatComponentTranslation(var7, new Object[0]));
         } else if(type == EnumPacketClient.MESSAGE) {
            var7 = StatCollector.translateToLocal(Server.readString(buffer));
            var8 = Server.readString(buffer);
            QuestAchievement var15 = new QuestAchievement(var8, var7);
            Minecraft.getMinecraft().guiAchievement.func_146256_a(var15);
            ObfuscationReflectionHelper.setPrivateValue(GuiAchievement.class, Minecraft.getMinecraft().guiAchievement, var15.getDescription(), 4);
         } else {
            int var11;
            if(type == EnumPacketClient.SYNCRECIPES_ADD) {
               NBTTagList var9 = Server.readNBT(buffer).getTagList("recipes", 10);
               if(var9 == null) {
                  return;
               }

               for(var11 = 0; var11 < var9.tagCount(); ++var11) {
                  RecipeCarpentry var14 = RecipeCarpentry.read(var9.getCompoundTagAt(var11));
                  RecipeController.syncRecipes.put(Integer.valueOf(var14.id), var14);
               }
            } else if(type == EnumPacketClient.SYNCRECIPES_WORKBENCH) {
               RecipeController.reloadGlobalRecipes(RecipeController.syncRecipes);
               RecipeController.syncRecipes = new HashMap();
            } else if(type == EnumPacketClient.SYNCRECIPES_CARPENTRYBENCH) {
               RecipeController.instance.anvilRecipes = RecipeController.syncRecipes;
               RecipeController.syncRecipes = new HashMap();
            } else if(type == EnumPacketClient.DIALOG) {
               config = Minecraft.getMinecraft().theWorld.getEntityByID(buffer.readInt());
               if(config == null || !(config instanceof EntityNPCInterface)) {
                  return;
               }

               NoppesUtil.openDialog(Server.readNBT(buffer), (EntityNPCInterface)config, player);
            } else if(type == EnumPacketClient.DIALOG_DUMMY) {
               EntityDialogNpc var10 = new EntityDialogNpc(player.worldObj);
               var10.display.name = Server.readString(buffer);
               EntityUtil.Copy(player, var10);
               NoppesUtil.openDialog(Server.readNBT(buffer), var10, player);
            } else if(type == EnumPacketClient.QUEST_COMPLETION) {
               NoppesUtil.guiQuestCompletion(player, Server.readNBT(buffer));
            } else if(type == EnumPacketClient.EDIT_NPC) {
               config = Minecraft.getMinecraft().theWorld.getEntityByID(buffer.readInt());
               if(config == null || !(config instanceof EntityNPCInterface)) {
                  return;
               }

               NoppesUtil.setLastNpc((EntityNPCInterface)config);
            } else if(type == EnumPacketClient.PLAY_MUSIC) {
               MusicController.Instance.playMusic(Server.readString(buffer), player);
            } else if(type == EnumPacketClient.PLAY_SOUND) {
               MusicController.Instance.playSound(Server.readString(buffer), buffer.readFloat(), buffer.readFloat(), buffer.readFloat());
            } else {
               Entity var12;
               NBTTagCompound var13;
               if(type == EnumPacketClient.UPDATE_NPC) {
                  var13 = Server.readNBT(buffer);
                  var12 = Minecraft.getMinecraft().theWorld.getEntityByID(var13.getInteger("EntityId"));
                  if(var12 == null || !(var12 instanceof EntityNPCInterface)) {
                     return;
                  }

                  ((EntityNPCInterface)var12).readSpawnData(var13);
               } else if(type == EnumPacketClient.ROLE) {
                  var13 = Server.readNBT(buffer);
                  var12 = Minecraft.getMinecraft().theWorld.getEntityByID(var13.getInteger("EntityId"));
                  if(var12 == null || !(var12 instanceof EntityNPCInterface)) {
                     return;
                  }

                  ((EntityNPCInterface)var12).advanced.setRole(var13.getInteger("Role"));
                  ((EntityNPCInterface)var12).roleInterface.readFromNBT(var13);
                  NoppesUtil.setLastNpc((EntityNPCInterface)var12);
               } else if(type == EnumPacketClient.GUI) {
                  EnumGuiType var16 = EnumGuiType.values()[buffer.readInt()];
                  CustomNpcs.proxy.openGui(NoppesUtil.getLastNpc(), var16, buffer.readInt(), buffer.readInt(), buffer.readInt());
               } else if(type == EnumPacketClient.PARTICLE) {
                  NoppesUtil.spawnParticle(buffer);
               } else if(type == EnumPacketClient.DELETE_NPC) {
                  config = Minecraft.getMinecraft().theWorld.getEntityByID(buffer.readInt());
                  if(config == null || !(config instanceof EntityNPCInterface)) {
                     return;
                  }

                  ((EntityNPCInterface)config).delete();
               } else if(type == EnumPacketClient.SCROLL_LIST) {
                  NoppesUtil.setScrollList(buffer);
               } else if(type == EnumPacketClient.SCROLL_DATA) {
                  NoppesUtil.setScrollData(buffer);
               } else if(type == EnumPacketClient.SCROLL_DATA_PART) {
                  NoppesUtil.addScrollData(buffer);
               } else {
                  GuiScreen var18;
                  if(type == EnumPacketClient.SCROLL_SELECTED) {
                     var18 = Minecraft.getMinecraft().currentScreen;
                     if(var18 == null || !(var18 instanceof IScrollData)) {
                        return;
                     }

                     var8 = Server.readString(buffer);
                     ((IScrollData)var18).setSelected(var8);
                  } else if(type == EnumPacketClient.GUI_REDSTONE) {
                     NoppesUtil.saveRedstoneBlock(player, Server.readNBT(buffer));
                  } else if(type == EnumPacketClient.GUI_WAYPOINT) {
                     NoppesUtil.saveWayPointBlock(player, Server.readNBT(buffer));
                  } else if(type == EnumPacketClient.CLONE) {
                     var13 = Server.readNBT(buffer);
                     NoppesUtil.openGUI(player, new GuiNpcMobSpawnerAdd(var13));
                  } else if(type == EnumPacketClient.GUI_DATA) {
                     Object var20 = Minecraft.getMinecraft().currentScreen;
                     if(var20 == null) {
                        return;
                     }

                     if(var20 instanceof GuiNPCInterface && ((GuiNPCInterface)var20).hasSubGui()) {
                        var20 = ((GuiNPCInterface)var20).getSubGui();
                     } else if(var20 instanceof GuiContainerNPCInterface && ((GuiContainerNPCInterface)var20).hasSubGui()) {
                        var20 = ((GuiContainerNPCInterface)var20).getSubGui();
                     }

                     if(var20 instanceof IGuiData) {
                        ((IGuiData)var20).setGuiData(Server.readNBT(buffer));
                     }
                  } else {
                     NBTTagCompound var17;
                     if(type == EnumPacketClient.GUI_ERROR) {
                        var18 = Minecraft.getMinecraft().currentScreen;
                        if(var18 == null || !(var18 instanceof IGuiError)) {
                           return;
                        }

                        var11 = buffer.readInt();
                        var17 = Server.readNBT(buffer);
                        ((IGuiError)var18).setError(var11, var17);
                     } else if(type == EnumPacketClient.GUI_CLOSE) {
                        var18 = Minecraft.getMinecraft().currentScreen;
                        if(var18 == null) {
                           return;
                        }

                        if(var18 instanceof IGuiClose) {
                           var11 = buffer.readInt();
                           var17 = Server.readNBT(buffer);
                           ((IGuiClose)var18).setClose(var11, var17);
                        }

                        Minecraft var21 = Minecraft.getMinecraft();
                        var21.displayGuiScreen((GuiScreen)null);
                        var21.setIngameFocus();
                     } else if(type == EnumPacketClient.VILLAGER_LIST) {
                        MerchantRecipeList var23 = MerchantRecipeList.func_151390_b(new PacketBuffer(buffer));
                        ServerEventsHandler.Merchant.setRecipes(var23);
                     } else {
                        int var19;
                        int var22;
                        if(type == EnumPacketClient.OPEN_BOOK) {
                           var22 = buffer.readInt();
                           var11 = buffer.readInt();
                           var19 = buffer.readInt();
                           NoppesUtil.openGUI(player, new GuiBook(player, ItemStack.loadItemStackFromNBT(Server.readNBT(buffer)), var22, var11, var19));
                        } else if(type == EnumPacketClient.CONFIG) {
                           var22 = buffer.readInt();
                           if(var22 == 0) {
                              var8 = Server.readString(buffer);
                              var19 = buffer.readInt();
                              if(!var8.isEmpty()) {
                                 CustomNpcs.FontType = var8;
                                 CustomNpcs.FontSize = var19;
                                 ClientProxy.Font = new ClientProxy.FontContainer(CustomNpcs.FontType, CustomNpcs.FontSize);
                                 CustomNpcs.Config.updateConfig();
                                 player.addChatMessage(new ChatComponentTranslation("Font set to %s", new Object[]{ClientProxy.Font.getName()}));
                              } else {
                                 player.addChatMessage(new ChatComponentTranslation("Current font is %s", new Object[]{ClientProxy.Font.getName()}));
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
      }

   }
}
