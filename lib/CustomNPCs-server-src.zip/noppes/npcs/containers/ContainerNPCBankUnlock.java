package noppes.npcs.containers;

import net.minecraft.entity.player.EntityPlayer;
import noppes.npcs.containers.ContainerNPCBankInterface;

public class ContainerNPCBankUnlock extends ContainerNPCBankInterface {

   public ContainerNPCBankUnlock(EntityPlayer player, int slot, int bankid) {
      super(player, slot, bankid);
   }
}
