package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileNpcContainer;

public class TileCrate extends TileNpcContainer {

   public String getName() {
      return "tile.npcCrate.name";
   }
}
