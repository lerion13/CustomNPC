package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileBanner;

public class TileSign extends TileBanner {

}
