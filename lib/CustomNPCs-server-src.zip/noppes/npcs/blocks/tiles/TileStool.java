package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileColorable;

public class TileStool extends TileColorable {

}
