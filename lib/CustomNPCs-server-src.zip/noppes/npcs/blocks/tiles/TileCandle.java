package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileLamp;

public class TileCandle extends TileLamp {

}
