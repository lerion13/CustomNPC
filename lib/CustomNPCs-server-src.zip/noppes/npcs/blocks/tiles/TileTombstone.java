package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileBigSign;

public class TileTombstone extends TileBigSign {

}
