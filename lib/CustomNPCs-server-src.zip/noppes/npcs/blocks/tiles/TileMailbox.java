package noppes.npcs.blocks.tiles;

import net.minecraft.tileentity.TileEntity;

public class TileMailbox extends TileEntity {

   public boolean canUpdate() {
      return false;
   }
}
