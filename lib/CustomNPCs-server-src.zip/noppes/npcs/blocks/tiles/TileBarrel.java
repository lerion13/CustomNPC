package noppes.npcs.blocks.tiles;

import noppes.npcs.blocks.tiles.TileNpcContainer;

public class TileBarrel extends TileNpcContainer {

   public String getName() {
      return "tile.npcBarrel.name";
   }
}
